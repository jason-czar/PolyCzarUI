// App.jsx
import React, { useState, useEffect } from 'react';
import OptionChain from './components/OptionChain';
import DateSelector from './components/DateSelector';
import TradeModal from './components/TradeModal';
import { getCurrentMarketData } from './utils/polymarket';

function App() {
  const [currentEvent, setCurrentEvent] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [tradeDetails, setTradeDetails] = useState(null);
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);

  useEffect(() => {
    const fetchCurrentEvent = async () => {
      const data = await getCurrentMarketData();
      setCurrentEvent(data);
    };
    fetchCurrentEvent();
  }, []);

  const handleTrade = (optionDetails) => {
    setTradeDetails(optionDetails);
    setIsTradeModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="max-w-4xl mx-auto">
        <header className="flex justify-between items-center mb-4">
          <h1 className="text-xl font-bold">{currentEvent?.title || 'Loading...'}</h1>
          <button onClick={() => window.close()} className="text-gray-400">
            ✕
          </button>
        </header>
        
        <DateSelector 
          selectedDate={selectedDate}
          onDateSelect={setSelectedDate}
          availableDates={currentEvent?.dates || []}
        />
        
        {currentEvent && (
          <OptionChain
            eventData={currentEvent}
            selectedDate={selectedDate}
            onTrade={handleTrade}
          />
        )}
        
        <TradeModal
          isOpen={isTradeModalOpen}
          onClose={() => setIsTradeModalOpen(false)}
          tradeDetails={tradeDetails}
        />
      </div>
    </div>
  );
}

export default App;