// DateSelector.jsx
import React from 'react';

function DateSelector({ selectedDate, onDateSelect, availableDates }) {
  const formatDate = (date) => {
    const d = new Date(date);
    const month = d.toLocaleString('default', { month: 'short' });
    const day = d.getDate();
    return { month, day };
  };

  return (
    <div className="flex overflow-x-auto mb-4 gap-2 pb-2">
      
      {availableDates.map((date) => {
        const { month, day } = formatDate(date);
        const isSelected = selectedDate === date;
        
        return (
          <button
            key={date}
            onClick={() => onDateSelect(date)}
            className={`px-4 py-1 rounded-full ${
              isSelected ? 'bg-green-500 text-black' : 'text-green-500'
            }`}
          >
            {month} {day}
          </button>
        );
      })}
    </div>
  );
}

export default DateSelector;