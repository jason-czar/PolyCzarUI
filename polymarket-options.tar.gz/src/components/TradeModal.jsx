// TradeModal.jsx
import React, { useState } from 'react';

function TradeModal({ isOpen, onClose, tradeDetails }) {
  const [quantity, setQuantity] = useState(1);
  
  if (!isOpen || !tradeDetails) return null;

  const total = (quantity * tradeDetails.price).toFixed(2);
  const maxProfit = tradeDetails.type === 'call' ? 'Unlimited' : 
    ((tradeDetails.strike - tradeDetails.price) * quantity).toFixed(2);
  const maxLoss = (total * 100).toFixed(2);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center">
      <div className="w-full max-w-md p-4">
        <div className="flex justify-between items-center mb-6">
          <button onClick={onClose} className="text-green-500">✕</button>
          <div className="text-right">Limit order</div>
        </div>

        <h2 className="text-xl mb-2">
          {tradeDetails.orderType === 'buy' ? 'Buy' : 'Sell'} {tradeDetails.strike} 
          {tradeDetails.type.toUpperCase()} {tradeDetails.expiry}
        </h2>

        <div className="space-y-4">
          <div className="flex justify-between">
            <span>Limit price</span>
            <div>
              <span className="text-green-500">
                Bid ${(tradeDetails.price - 0.10).toFixed(2)}
              </span>
              <span className="mx-2">·</span>
              <span className="text-green-500">
                Ask ${tradeDetails.price}
              </span>
            </div>
          </div>

          <div className="flex justify-between">
            <span>Quantity</span>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
              className="bg-transparent border-b border-gray-700 w-20 text-right"
            />
          </div>

          <div className="flex justify-between">
            <span>Estimated cost</span>
            <span>${total}</span>
          </div>

          <div className="pt-4 border-t border-gray-800">
            <div className="grid grid-cols-3 gap-4 text-center text-sm text-gray-400">
              <div>
                <div>Max profit</div>
                <div className="text-white">{maxProfit}</div>
              </div>
              <div>
                <div>Breakeven</div>
                <div className="text-white">${tradeDetails.breakeven}</div>
              </div>
              <div>
                <div>Max loss</div>
                <div className="text-white">-${maxLoss}</div>
              </div>
            </div>
          </div>

          <button className="w-full py-3 bg-green-500 text-black rounded-lg mt-4">
            Review
          </button>
        </div>
      </div>
    </div>
  );
}

export default TradeModal;