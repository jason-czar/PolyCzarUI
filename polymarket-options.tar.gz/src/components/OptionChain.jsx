// OptionChain.jsx
import React, { useState } from 'react';
import { calculateBreakeven, calculateProfitChance } from '../utils/calculations';

function OptionChain({ eventData, selectedDate, onTrade }) {
  const [activeTab, setActiveTab] = useState('call');
  const [activeOrderType, setActiveOrderType] = useState('buy');

  const renderOption = (option) => {
    const isCall = activeTab === 'call';
    const breakeven = calculateBreakeven(option, isCall);
    const profitChance = calculateProfitChance(option, isCall);
    const colorClass = isCall ? 'text-green-500' : 'text-red-500';

    return (
      <div key={option.strike} className="border-b border-gray-800 py-3">
        <div className="flex justify-between items-center">
          <div>
            <div className="text-lg">${option.strike} {activeTab.toUpperCase()}</div>
            <div className="text-sm text-gray-400">
              Breakeven: ${breakeven}
            </div>
            <div className={`text-sm ${colorClass}`}>
              {profitChance}% Today
            </div>
          </div>
          <button
            onClick={() => onTrade({ ...option, type: activeTab, orderType: activeOrderType })}
            className={`flex items-center rounded-full px-4 py-2 ${colorClass} border border-current`}
          >
            ${option.price}
            <span className="ml-2">+</span>
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-gray-900 rounded-lg p-4">
      <div className="flex mb-4 gap-4">
        <div className="flex bg-gray-800 rounded-lg p-1">
          <button
            className={`px-4 py-2 rounded-md ${activeOrderType === 'buy' ? 'bg-gray-700' : ''}`}
            onClick={() => setActiveOrderType('buy')}
          >
            Buy
          </button>
          <button
            className={`px-4 py-2 rounded-md ${activeOrderType === 'sell' ? 'bg-gray-700' : ''}`}
            onClick={() => setActiveOrderType('sell')}
          >
            Sell
          </button>
        </div>
        
        <div className="flex bg-gray-800 rounded-lg p-1">
          <button
            className={`px-4 py-2 rounded-md ${activeTab === 'call' ? 'bg-gray-700' : ''}`}
            onClick={() => setActiveTab('call')}
          >
            Call
          </button>
          <button
            className={`px-4 py-2 rounded-md ${activeTab === 'put' ? 'bg-gray-700' : ''}`}
            onClick={() => setActiveTab('put')}
          >
            Put
          </button>
        </div>
      </div>

      <div className="text-center text-green-500 py-2 border-t border-b border-gray-800">
        Share price: ${eventData.currentPrice}
      </div>

      <div className="mt-4 space-y-2">
        {eventData.options
          .filter(opt => opt.type === activeTab)
          .map(renderOption)}
      </div>
    </div>
  );
}

export default OptionChain;