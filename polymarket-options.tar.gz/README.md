# Polymarket Options Chain Chrome Extension

## Overview
A Chrome extension for visualizing options chains for Polymarket events. This extension provides an intuitive interface for viewing and analyzing options data with features like dynamic date generation and trade modal integration.

## Features
- Dynamic generation of upcoming Friday dates
- Options chain visualization with strike prices and premiums
- Trade modal for detailed order placement
- Real-time breakeven and profit chance calculations
- Automatic date selection for upcoming Fridays

## Installation
1. Download the extension files by either:
   - Cloning this repository: `git clone https://github.com/your-username/polymarket-options.git`
   - Downloading the ZIP file and extracting it
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" using the toggle in the top right
4. Click "Load unpacked" and select the `dist` directory from the downloaded files

## Development Setup
1. Install dependencies:
   
2. Start the development server:
   
3. Build for production:
   
4. The built extension will be in the `dist` directory

## Project Structure